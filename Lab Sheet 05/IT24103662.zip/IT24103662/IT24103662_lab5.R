# Set working directory
setwd("C:\\Users\\REDTECH\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24103662")

#QUESTION 01

# Import dataset
Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE,sep = ",")

# View first few rows
head(Delivery_Times)



#To edit data
fix(Delivery_Times)

#To Rename
names(Delivery_Times) <-("Time") 
attach(Delivery_Times)



#QUESTION 02

#Creat a histogram
histogram<-hist(Time,main="histogram for deliver times",breaks = seq(20,70,length=10),right = FALSE,col =("orange"))

#QUESTION 03

# Question 03:
# The distribution of delivery times is approximately symmetric and bell-shaped,
# centered around 40 minutes. Most deliveries cluster near the middle, while 
# relatively fewer are very short or very long. There is a slight right skew, 
# indicating that a small number of deliveries take longer than the typical time.






#QUESTION 04
breaks<-round(histogram$breaks)
freq<- histogram$counts   
mids<-histogram$mids      


cum.freq<-cumsum(freq)
new<-c()
for(i in 1:length(breaks)){
  if(i==1){
    new[i]=0
    
  }else{
    new[i]=cum.freq[i-1]
  }
}


#Creat a cumulative frequency polygon

plot(breaks,new,type = 'l',main="cumulative frequency polygon for Delivery times",xlab ="Delivery times",ylab = "cumulative frequency" ,ylim =c(0,max(cum.freq)) )

